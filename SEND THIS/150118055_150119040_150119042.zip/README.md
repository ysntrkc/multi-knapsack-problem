# MultiKnapsackProblem

In order to run this program, you need to specify the name of both input and output text files.
The program will fill the knapsack and write it to the output file.